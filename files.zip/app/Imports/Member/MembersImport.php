<?php

namespace App\Imports\Member;

use App\Models\Member\Member;
use App\Models\Member\MemberImportLog;
use App\Models\Company\Company;
use App\Models\Branch\Branch;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class MembersImport implements ToCollection, WithHeadingRow, WithValidation
{
    protected $predefinedColumns = [
        'reference',
        'first_name',
        'last_name',
        'gender',
        'national_id_number',
        'date_of_birth',
        'phone_code',
        'phone_number',
        'email',
        'address',
        'status',
    ];

    public $company, $branch, $user, $importId;
    protected $failedRows = [];
    protected $successCount = 0;
    protected $failedCount = 0;

    public function __construct($companyId = null, $branchId, $userId, $importId = null)
    {
        if ($companyId) {
            $this->company = Company::find($companyId);
            if (!$this->company) {
                throw new \Exception('Company not found');
            }
        }

        $this->branch = Branch::find($branchId);
        if (!$this->branch) {
            throw new \Exception('Branch not found');
        }

        $this->user = User::find($userId);
        if (!$this->user) {
            throw new \Exception('User not found');
        }

        $this->importId = $importId;
    }

    public function collection(Collection $rows)
    {
        Log::info('Starting Member Import Collection...');

        // Reset counters
        $this->successCount = 0;
        $this->failedCount = 0;

        // Start transaction
        DB::beginTransaction();

        try {
            foreach ($rows as $rowNumber => $row) {
                if ($rowNumber === 0) {
                    // Validate header row
                    $this->validateHeaderRow($row);
                    continue;
                }

                // Process each row
                $this->processRow($row, $rowNumber);
            }

            DB::commit();

            Log::info("Member import completed. Success: {$this->successCount}, Failed: {$this->failedCount}");

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Member import failed: ' . $e->getMessage());

            // Log the general error as a failed row
            $this->logGeneralError($e->getMessage());

            // Don't throw the exception - let the import continue with logging
            // throw $e;
        }
    }

    private function validateHeaderRow($row)
    {
        $missingColumns = [];

        // Check if required columns are present in the header
        $requiredColumns = ['first_name', 'last_name', 'gender'];

        foreach ($requiredColumns as $column) {
            if (!isset($row[$column]) || empty($row[$column])) {
                $missingColumns[] = $column;
            }
        }

        if (!empty($missingColumns)) {
            $errorMessage = "Missing required columns in header: " . implode(', ', $missingColumns);
            Log::error($errorMessage);
            $this->logGeneralError($errorMessage);
        }
    }

    private function processRow($row, $rowNumber)
    {
        $importComment = '';
        Log::info("Processing row {$rowNumber}");

        try {
            // Skip empty rows (where all required fields are empty)
            if ($this->isRowEmpty($row)) {
                Log::info("Skipping empty row {$rowNumber}");
                return;
            }

            // Perform validation
            $this->validateRow($row, $rowNumber);

            // Process gender
            $gender = $this->processGender($row);

            // Generate reference if empty
            if (empty($row['reference'])) {
                $row['reference'] = $this->generateMemberReference();
            }

            // Check if member exists
            $this->checkMemberExistence($row);

            // Create member
            $member = $this->createMember($row, $gender);

            Log::info("Successfully created member: {$member->reference}");
            $this->successCount++;

        } catch (\Exception $e) {
            // Log error and continue processing other rows
            $this->handleRowError($row, $rowNumber, $e->getMessage(), $importComment);
            $this->failedCount++;

            // Continue to next row - don't throw exception
            return;
        }
    }

    private function isRowEmpty($row)
    {
        $requiredFields = ['first_name', 'last_name', 'gender'];

        foreach ($requiredFields as $field) {
            if (!empty($row[$field])) {
                return false;
            }
        }

        return true;
    }

    private function handleRowError($row, $rowNumber, $errorMessage, $importComment)
    {
        $row['row'] = $rowNumber + 1;
        $row['column'] = $this->getColumnFromError($errorMessage);
        $row['comment'] = $importComment ?: $errorMessage;

        Log::error("Error in row {$row['row']}, column {$row['column']}: {$row['comment']}");
        $this->logFailedRow($row, $rowNumber, $errorMessage);
    }

    private function logFailedRow($row, $rowNumber, $errorMessage)
    {
        if ($this->importId) {
            try {
                MemberImportLog::create([
                    'log_message' => "Error in row $rowNumber: $errorMessage",
                    'member_import_id' => $this->importId,
                    'is_resolved' => false,
                    'data' => $row,
                ]);
            } catch (\Exception $e) {
                Log::error("Failed to create import log: " . $e->getMessage());
            }
        }
    }

    private function logGeneralError($errorMessage)
    {
        if ($this->importId) {
            try {
                MemberImportLog::create([
                    'log_message' => "General import error: $errorMessage",
                    'member_import_id' => $this->importId,
                    'is_resolved' => false,
                    'data' => ['error' => $errorMessage],
                ]);
            } catch (\Exception $e) {
                Log::error("Failed to create general error log: " . $e->getMessage());
            }
        }
    }

    public function headingRow(): int
    {
        return 1;
    }

    public function rules(): array
    {
        return [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'gender' => 'required|in:male,female,Male,Female,M,F',
            'date_of_birth' => 'nullable|date|before:today',
            'email' => 'nullable|email|unique:members,email',
            'national_id_number' => 'nullable|string|unique:members,national_id_number',
            'reference' => 'nullable|string|unique:members,reference',
            'status' => 'nullable|in:active,inactive,Active,Inactive',
        ];
    }

    public function customValidationMessages()
    {
        return [
            '*.first_name.required' => 'First name is required in row :row.',
            '*.last_name.required' => 'Last name is required in row :row.',
            '*.gender.required' => 'Gender is required in row :row.',
            '*.gender.in' => 'Gender must be Male or Female in row :row.',
            '*.date_of_birth.date' => 'Date of birth must be a valid date in row :row.',
            '*.date_of_birth.before' => 'Date of birth must be before today in row :row.',
            '*.email.email' => 'Email must be a valid email address in row :row.',
            '*.email.unique' => 'Email already exists in row :row.',
            '*.national_id_number.unique' => 'National ID number already exists in row :row.',
            '*.reference.unique' => 'Reference number already exists in row :row.',
            '*.status.in' => 'Status must be Active or Inactive in row :row.',
        ];
    }

    private function validateRow($row, $rowNumber)
    {
        // Check if row has any data before validating
        if ($this->isRowEmpty($row)) {
            throw new \Exception('Row is empty - missing required fields');
        }

        // Validate using Laravel validator
        $validator = Validator::make($row->toArray(), $this->rules(), $this->customValidationMessages());

        if ($validator->fails()) {
            // Collect all error messages
            $errorMessages = [];
            foreach ($validator->errors()->all() as $error) {
                $errorMessages[] = str_replace(':row', $rowNumber + 1, $error);
            }

            throw new \Exception(implode(' ', $errorMessages));
        }
    }

    private function processGender($row)
    {
        if (!isset($row['gender'])) {
            return 'other';
        }

        $gender = strtolower(trim($row['gender']));

        if (in_array($gender, ['male', 'm'])) {
            return 'male';
        } elseif (in_array($gender, ['female', 'f'])) {
            return 'female';
        } else {
            return 'other';
        }
    }

    private function checkMemberExistence($row)
    {
        // Check by reference
        if (isset($row['reference']) && Member::where('reference', $row['reference'])->exists()) {
            throw new \Exception('Member with this reference already exists');
        }

        // Check by email
        if (isset($row['email']) && Member::where('email', $row['email'])->exists()) {
            throw new \Exception('Member with this email already exists');
        }

        // Check by national ID
        if (isset($row['national_id_number']) && Member::where('national_id_number', $row['national_id_number'])->exists()) {
            throw new \Exception('Member with this national ID number already exists');
        }
    }

    private function createMember($row, $gender)
    {
        // Prepare phone data
        $phone = null;
        if (!empty($row['phone_code']) && !empty($row['phone_number'])) {
            $phone = [
                'code' => $this->formatPhoneCode($row['phone_code']),
                'number' => $this->formatPhoneNumber($row['phone_number'])
            ];
        }

        // Prepare member data
        $memberData = [
            'reference' => $row['reference'],
            'first_name' => $row['first_name'],
            'last_name' => $row['last_name'],
            'gender' => $gender,
            'date_of_birth' => $row['date_of_birth'] ?? null,
            'email' => $row['email'] ?? null,
            'national_id_number' => $row['national_id_number'] ?? null,
            'phone' => $phone,
            'address' => $row['address'] ?? null,
            'status' => isset($row['status']) ? strtolower($row['status']) : 'active',
            'created_by_id' => $this->user->id,
        ];

        // Add company and branch if applicable
        // if ($this->company) {
        //     $memberData['company_id'] = $this->company->id;
        // }

        // if ($this->branch) {
        //     $memberData['branch_id'] = $this->branch->id;
        // }

        // Create the member
        return Member::create($memberData);
    }

    private function formatPhoneCode($code)
    {
        // Ensure phone code starts with +
        $code = trim($code);
        if (!Str::startsWith($code, '+')) {
            $code = '+' . $code;
        }
        return $code;
    }

    private function formatPhoneNumber($number)
    {
        // Remove all non-digit characters
        return preg_replace('/\D/', '', $number);
    }

    private function generateMemberReference()
    {
        do {
            $reference = 'MBR-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        } while (Member::where('reference', $reference)->exists());

        return $reference;
    }

    private function getColumnFromError($errorMessage)
    {
        preg_match('/column: (\w+)/', $errorMessage, $matches);
        return $matches[1] ?? 'unknown';
    }

    public function getFailedRows()
    {
        return $this->failedRows;
    }

    public function getImportStatistics()
    {
        return [
            'success_count' => $this->successCount,
            'failed_count' => $this->failedCount,
            'total_processed' => $this->successCount + $this->failedCount,
        ];
    }
}
