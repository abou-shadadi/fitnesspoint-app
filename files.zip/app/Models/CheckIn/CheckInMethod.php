<?php

namespace App\Models\CheckIn;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CheckInMethod extends Model
{
    use HasFactory;
    protected $guarded = [];
}
