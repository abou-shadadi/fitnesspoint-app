<?php

namespace App\Models\Company;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyDesignation extends Model
{
    protected $guarded = [];
    use HasFactory;
}
