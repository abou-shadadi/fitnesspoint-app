<?php

namespace App\Models\Duration;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DurationType extends Model
{
    use HasFactory;
    protected $guarded = [];
}
