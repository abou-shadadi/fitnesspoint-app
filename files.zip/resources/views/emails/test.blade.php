<h1>This is a test email from Laravel</h1>
<p>Everything is working fine!</p>
